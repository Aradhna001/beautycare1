// js of wedding kit
function print1()
{
    var one  = document.getElementById("box1").value
     var package1 =  one*9210
     document.getElementById("paragraph1").innerHTML = "Rs:" + package1 
}

function print2()
{
    var one  = document.getElementById("box2").value
     var package1 =  one*12210
     document.getElementById("paragraph2").innerHTML = "Rs:" + package1 
}
function print3()
{
    var one  = document.getElementById("box3").value
     var package1 =  one*6105
     document.getElementById("paragraph3").innerHTML = "Rs:" + package1 
}
function print4()
{
    var one  = document.getElementById("box4").value
     var package1 =  one*10020
     document.getElementById("paragraph4").innerHTML = "Rs:" + package1 
}
function print5()
{
    var one  = document.getElementById("box5").value
     var package1 =  one*1225
     document.getElementById("paragraph5").innerHTML = "Rs:" + package1 
}
function print6()
{
    var one  = document.getElementById("box6").value
     var package1 =  one*6250
     document.getElementById("paragraph6").innerHTML = "Rs:" + package1 
}
// js of skincare
function print7()
{
    var one  = document.getElementById("box7").value
     var package1 =  one*9210
     document.getElementById("paragraph7").innerHTML = "Rs:" + package1 
}

function print8()
{
    var one  = document.getElementById("box8").value
     var package1 =  one*12210
     document.getElementById("paragraph8").innerHTML = "Rs:" + package1 
}
function print9()
{
    var one  = document.getElementById("box9").value
     var package1 =  one*1299
     document.getElementById("paragraph9").innerHTML = "Rs:" + package1 
}
function print10()
{
    var one  = document.getElementById("box10").value
     var package1 =  one*1020
     document.getElementById("paragraph10").innerHTML = "Rs:" + package1 
}
function print11()
{
    var one  = document.getElementById("box11").value
     var package1 =  one*1255
     document.getElementById("paragraph11").innerHTML = "Rs:" + package1 
}
function print12()
{
    var one  = document.getElementById("box12").value
     var package1 =  one*2320
     document.getElementById("paragraph12").innerHTML = "Rs:" + package1 
}
// js of haircare
function print13()
{
    var one  = document.getElementById("box13").value
     var package1 =  one*2850
     document.getElementById("paragraph13").innerHTML = "Rs:" + package1 
}

function print14()
{
    var one  = document.getElementById("box14").value
     var package1 =  one*9210
     document.getElementById("paragraph14").innerHTML = "Rs:" + package1 
}
function print15()
{
    var one  = document.getElementById("box15").value
     var package1 =  one*6075
     document.getElementById("paragraph15").innerHTML = "Rs:" + package1 
}
function print16()
{
    var one  = document.getElementById("box16").value
     var package1 =  one*1360
     document.getElementById("paragraph16").innerHTML = "Rs:" + package1 
}
function print17()
{
    var one  = document.getElementById("box17").value
     var package1 =  one*4350
     document.getElementById("paragraph17").innerHTML = "Rs:" + package1 
}
function print18()
{
    var one  = document.getElementById("box18").value
     var package1 =  one*5260
     document.getElementById("paragraph18").innerHTML = "Rs:" + package1 
}
// js of nailpaint
function print19()
{
    var one  = document.getElementById("box19").value
     var package1 =  one*450
     document.getElementById("paragraph19").innerHTML = "Rs:" + package1 
}

function print20()
{
    var one  = document.getElementById("box20").value
     var package1 =  one*450
     document.getElementById("paragraph20").innerHTML = "Rs:" + package1 
}
function print21()
{
    var one  = document.getElementById("box21").value
     var package1 =  one*450
     document.getElementById("paragraph21").innerHTML = "Rs:" + package1 
}
function print22()
{
    var one  = document.getElementById("box22").value
     var package1 =  one*450
     document.getElementById("paragraph22").innerHTML = "Rs:" + package1 
}
function print23()
{
    var one  = document.getElementById("box23").value
     var package1 =  one*450
     document.getElementById("paragraph23").innerHTML = "Rs:" + package1 
}
function print24()
{
    var one  = document.getElementById("box24").value
     var package1 =  one*450
     document.getElementById("paragraph24").innerHTML = "Rs:" + package1 
}





// js of nailart
function print25()
{
    var one  = document.getElementById("box25").value
     var package1 =  one*2850
     document.getElementById("paragraph25").innerHTML = "Rs:" + package1 
}

function print26()
{
    var one  = document.getElementById("box26").value
     var package1 =  one*1210
     document.getElementById("paragraph26").innerHTML = "Rs:" + package1 
}
function print27()
{
    var one  = document.getElementById("box27").value
     var package1 =  one*1250
     document.getElementById("paragraph27").innerHTML = "Rs:" + package1 
}
function print28()
{
    var one  = document.getElementById("box28").value
     var package1 =  one*1450
     document.getElementById("paragraph28").innerHTML = "Rs:" + package1 
}
function print29()
{
    var one  = document.getElementById("box29").value
     var package1 =  one*1250
     document.getElementById("paragraph29").innerHTML = "Rs:" + package1 
}
function print30()
{
    var one  = document.getElementById("box30").value
     var package1 =  one*1250
     document.getElementById("paragraph30").innerHTML = "Rs:" + package1 
}
// js of makeupkit
function print31()
{
    var one  = document.getElementById("box31").value
     var package1 =  one*2850
     document.getElementById("paragraph31").innerHTML = "Rs:" + package1 
}

function print32()
{
    var one  = document.getElementById("box32").value
     var package1 =  one*9210
     document.getElementById("paragraph32").innerHTML = "Rs:" + package1 
}
function print33()
{
    var one  = document.getElementById("box33").value
     var package1 =  one*6075
     document.getElementById("paragraph33").innerHTML = "Rs:" + package1 
}
function print34()
{
    var one  = document.getElementById("box34").value
     var package1 =  one*1360
     document.getElementById("paragraph34").innerHTML = "Rs:" + package1 
}
function print35()
{
    var one  = document.getElementById("box35").value
     var package1 =  one*4350
     document.getElementById("paragraph35").innerHTML = "Rs:" + package1 
}
function print36()
{
    var one  = document.getElementById("box36").value
     var package1 =  one*6250
     document.getElementById("paragraph36").innerHTML = "Rs:" + package1 
}
// js of jwelllery items (necklaces)
function print37()
{
    var one  = document.getElementById("box37").value
     var package1 =  one*550
     document.getElementById("paragraph37").innerHTML = "Rs:" + package1 
}

function print38()
{
    var one  = document.getElementById("box38").value
     var package1 =  one*550
     document.getElementById("paragraph38").innerHTML = "Rs:" + package1 
}
function print39()
{
    var one  = document.getElementById("box39").value
     var package1 =  one*550
     document.getElementById("paragraph39").innerHTML = "Rs:" + package1 
}
function print40()
{
    var one  = document.getElementById("box40").value
     var package1 =  one*550
     document.getElementById("paragraph40").innerHTML = "Rs:" + package1 
}
function print41()
{
    var one  = document.getElementById("box41").value
     var package1 =  one*550
     document.getElementById("paragraph41").innerHTML = "Rs:" + package1 
}
function print42()
{
    var one  = document.getElementById("box42").value
     var package1 =  one*550
     document.getElementById("paragraph42").innerHTML = "Rs:" + package1 
}

// js of jwelllery items (earings
function print43()
{
    var one  = document.getElementById("box43").value
     var package1 =  one*550
     document.getElementById("paragraph43").innerHTML = "Rs:" + package1 
}

function print44()
{
    var one  = document.getElementById("box44").value
     var package1 =  one*550
     document.getElementById("paragraph44").innerHTML = "Rs:" + package1 
}
function print45()
{
    var one  = document.getElementById("box45").value
     var package1 =  one*550
     document.getElementById("paragraph45").innerHTML = "Rs:" + package1 
}
function print46()
{
    var one  = document.getElementById("box46").value
     var package1 =  one*550
     document.getElementById("paragraph46").innerHTML = "Rs:" + package1 
}
function print47()
{
    var one  = document.getElementById("box47").value
     var package1 =  one*550
     document.getElementById("paragraph47").innerHTML = "Rs:" + package1 
}
function print48()
{
    var one  = document.getElementById("box48").value
     var package1 =  one*550
     document.getElementById("paragraph48").innerHTML = "Rs:" + package1 
}
// js of jwelllery items (bracelet
function print49()
{
    var one  = document.getElementById("box49").value
     var package1 =  one*550
     document.getElementById("paragraph49").innerHTML = "Rs:" + package1 
}

function print50()
{
    var one  = document.getElementById("box50").value
     var package1 =  one*550
     document.getElementById("paragraph50").innerHTML = "Rs:" + package1 
}
function print51()
{
    var one  = document.getElementById("box51").value
     var package1 =  one*550
     document.getElementById("paragraph51").innerHTML = "Rs:" + package1 
}
function print52()
{
    var one  = document.getElementById("box52").value
     var package1 =  one*550
     document.getElementById("paragraph52").innerHTML = "Rs:" + package1 
}
function print53()
{
    var one  = document.getElementById("box53").value
     var package1 =  one*550
     document.getElementById("paragraph53").innerHTML = "Rs:" + package1 
}
function print54()
{
    var one  = document.getElementById("box54").value
     var package1 =  one*550
     document.getElementById("paragraph54").innerHTML = "Rs:" + package1 
}